#include "syscall.h"

main()
        {
                int     m;
                for (m=2020;m<=2030;m++)
                        PrintInt(m);
        }
