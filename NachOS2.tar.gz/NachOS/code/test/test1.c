#include "syscall.h"
main()
	{
		int	n;
		int sum;
		for (n=2000;n>2000;n--){
			//PrintInt(n);
		}
	}
