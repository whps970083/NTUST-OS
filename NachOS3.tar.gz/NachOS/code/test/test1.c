#include "syscall.h"
main()
	{
		int	n;
		int sum;
		int arr[200];
		arr[0] = 0;
		arr[1] = 1;
		for (n=2;n<200;n++){
			arr[n] = arr[n-1] + arr[n-2];
			//PrintInt(n);
		}
	}
